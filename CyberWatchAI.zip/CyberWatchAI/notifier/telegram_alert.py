import requests
import json
import os

# تحميل إعدادات التليجرام من ملف JSON
with open(os.path.join("notifier", "telegram_config.json"), "r") as f:
    cfg = json.load(f)

BOT_TOKEN = cfg["bot_token"]
CHAT_ID   = cfg["chat_id"]
API_URL   = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

def send_alert(message: str):
    payload = {
        "chat_id": CHAT_ID,
        "text": message,
        "parse_mode": "Markdown"
    }
    try:
        resp = requests.post(API_URL, data=payload, timeout=5)
        if resp.status_code == 200:
            print("[✔] تم إرسال التنبيه إلى تيليجرام.")
        else:
            print(f"[⚠] فشلت الإرسال ({resp.status_code}): {resp.text}")
    except Exception as e:
        print(f"[✖] خطأ أثناء الإرسال: {e}")

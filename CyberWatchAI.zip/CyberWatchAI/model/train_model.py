# model/train_model.py

import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from joblib import dump
import os

# مكان تخزين النماذج
MODEL_PATH = os.path.join("model", "anomaly_model.pkl")

def load_and_prepare():
    # نقوم بقراءة ملفات السجل
    df_proc = pd.read_csv("data/process_log.csv", parse_dates=["timestamp"])
    df_file = pd.read_csv("data/file_log.csv", parse_dates=["timestamp"])
    df_net  = pd.read_csv("data/network_log.csv", parse_dates=["timestamp"])

    # 1. تجهيز بيانات العمليات: نحول أسماء العمليات لرموز عددية، ونأخذ نسبة CPU و RAM
    df_proc["name_code"] = df_proc["name"].astype("category").cat.codes
    proc_feats = df_proc[["name_code", "cpu_percent", "memory_percent"]]

    # 2. تجهيز بيانات الملفات: نحول نوع الحدث لرمز، ونأخذ طول اسم الملف
    df_file["event_code"] = df_file["event_type"].astype("category").cat.codes
    df_file["path_len"]   = df_file["file_path"].str.len()
    file_feats = df_file[["event_code", "path_len"]]

    # 3. تجهيز بيانات الشبكة: نبني ميزة للبورتات وأخذ حالة الاتصال
    df_net["status_code"]   = df_net["status"].astype("category").cat.codes
    df_net["local_port"]    = df_net["local_port"].fillna(0)
    df_net["remote_port"]   = df_net["remote_port"].fillna(0)
    net_feats = df_net[["status_code", "local_port", "remote_port"]]

    # 4. دمج كل الميزات
    X = pd.concat([proc_feats, file_feats, net_feats], axis=1).fillna(0)

    return X

def train_and_save():
    X = load_and_prepare()
    # تهيئة وتدريب نموذج كشف الشذوذ
    model = IsolationForest(contamination=0.02, random_state=42)
    model.fit(X)

    # حفظ النموذج
    dump(model, MODEL_PATH)
    print(f"[✔] تم تدريب النموذج وحفظه في: {MODEL_PATH}")

if __name__ == "__main__":
    train_and_save()

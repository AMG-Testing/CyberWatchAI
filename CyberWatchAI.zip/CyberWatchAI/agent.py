import threading
import time
import os
import pandas as pd
import matplotlib

# استخدم backend غير تفاعلي لتجنب مشاكل تشغيل matplotlib في ثريدات
matplotlib.use('Agg')

import matplotlib.pyplot as plt
from joblib import load

from monitor.process_monitor   import start_monitoring as proc_mon
from monitor.file_monitor      import start_file_monitoring as file_mon
from monitor.network_monitor   import start_monitoring as net_mon
from notifier.telegram_alert   import send_alert

MODEL_PATH = "model/anomaly_model.pkl"
PLOT_PATH  = "output/anomaly_plot.png"

def detect_anomalies():
    # تحميل نموذج كشف الشذوذ المدرب مسبقًا
    model = load(MODEL_PATH)

    try:
        # قراءة آخر 100 سجل لكل مصدر بيانات
        df_proc = pd.read_csv("data/process_log.csv").tail(100)
        df_file = pd.read_csv("data/file_log.csv").tail(100)
        df_net  = pd.read_csv("data/network_log.csv").tail(100)
    except Exception as e:
        print(f"[!] خطأ بقراءة ملفات البيانات: {e}")
        return

    # التحقق من وجود بيانات كافية
    if df_proc.empty or df_file.empty or df_net.empty:
        print("[!] لا توجد بيانات كافية للكشف، انتظر قليلًا.")
        return

    # === تجهيز ميزات العمليات ===
    # تحويل أسماء العمليات إلى أرقام فئوية (ترميز كود)
    df_proc["name_code"] = df_proc["name"].astype("category").cat.codes
    proc_feats = df_proc[["name_code", "cpu_percent", "memory_percent"]]

    # === تجهيز ميزات الملفات ===
    # تحويل نوع الحدث إلى كود رقمي، وحساب طول مسار الملف
    df_file["event_code"] = df_file["event_type"].astype("category").cat.codes
    df_file["path_len"] = df_file["file_path"].str.len()
    file_feats = df_file[["event_code", "path_len"]]

    # === تجهيز ميزات الشبكة ===
    # تعويض القيم الناقصة بالبورتات بصفر
    df_net = df_net.fillna({"local_port": 0, "remote_port": 0})
    df_net["status_code"] = df_net["status"].astype("category").cat.codes
    net_feats = df_net[["status_code", "local_port", "remote_port"]]

    # دمج كل الميزات في جدول واحد
    X_new = pd.concat([proc_feats, file_feats, net_feats], axis=1).fillna(0)

    # التنبؤ بحالات الشذوذ: -1 = شاذ، 1 = طبيعي
    preds = model.predict(X_new)
    anomalies = X_new[preds == -1]

    if not anomalies.empty:
        # *** تحضير رسالة مفصلة للنشاط المشبوه ***
        msg = "*⚠️ تم اكتشاف سلوك شاذ!*\n"
        msg += f"عدد الحالات الشاذة: {len(anomalies)}\n\n"
        msg += "تفاصيل النشاطات الشاذة:\n"

        # نضيف تفاصيل كل نشاط شاذ حسب القسم (عمليات - ملفات - شبكة)
        for idx in anomalies.index:
            proc_row = df_proc.loc[idx] if idx in df_proc.index else None
            file_row = df_file.loc[idx] if idx in df_file.index else None
            net_row = df_net.loc[idx] if idx in df_net.index else None

            # مثال تفصيلي لعملية شاذة
            if proc_row is not None:
                msg += f"\n[عملية]\n"
                msg += f"- اسم العملية: {proc_row['name']}\n"
                msg += f"- CPU: {proc_row['cpu_percent']:.2f}%\n"
                msg += f"- RAM: {proc_row['memory_percent']:.2f}%\n"

            # مثال تفصيلي لملف شاذ
            if file_row is not None:
                msg += f"\n[ملف]\n"
                msg += f"- نوع الحدث: {file_row['event_type']}\n"
                msg += f"- مسار الملف: {file_row['file_path']}\n"

            # مثال تفصيلي لاتصال شبكة شاذ
            if net_row is not None:
                msg += f"\n[شبكة]\n"
                msg += f"- العملية: {net_row['process_name']}\n"
                msg += f"- الحالة: {net_row['status']}\n"
                msg += f"- المنفذ المحلي: {net_row['local_port']}\n"
                msg += f"- المنفذ البعيد: {net_row['remote_port']}\n"

        # إرسال التنبيه للتليجرام
        send_alert(msg)

        # حفظ رسم توضيحي للحالات (يمكن تعديل لعرض مزيد من التفاصيل)
        os.makedirs(os.path.dirname(PLOT_PATH), exist_ok=True)
        plt.figure(figsize=(8,4))
        plt.scatter(range(len(X_new)), X_new.iloc[:,0], c=preds, cmap='coolwarm')
        plt.title("Anomaly Detection (0=normal, -1=anomaly)")
        plt.savefig(PLOT_PATH)
        plt.close()

        print(f"[✔] تم حفظ المخطط في: {PLOT_PATH}")
    else:
        print("[✔] لا توجد حالات شاذة في هذه الجولة.")

def periodic_detection(interval=60):
    while True:
        time.sleep(interval)
        detect_anomalies()

def main():
    # شغل مراقبة العمليات (تسجيل بيانات كل 10 ثواني)
    threading.Thread(target=proc_mon, args=(10,), daemon=True).start()

    # شغل مراقبة الملفات (تسجيل التغيرات في المجلد المحدد كل ثانية)
    threading.Thread(target=file_mon, args=(r"E:\Program\Python\Caesar", 1), daemon=True).start()

    # شغل مراقبة الشبكة (تسجيل بيانات كل 10 ثواني)
    threading.Thread(target=net_mon, args=(10,), daemon=True).start()

    # شغل كشف الشذوذ كل 60 ثانية
    threading.Thread(target=periodic_detection, args=(60,), daemon=True).start()

    print("[🚀] CyberWatchAI قيد التشغيل. اضغط Ctrl+C لإيقاف.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[✖] إيقاف Agent... باي! 😊")

if __name__ == "__main__":
    main()

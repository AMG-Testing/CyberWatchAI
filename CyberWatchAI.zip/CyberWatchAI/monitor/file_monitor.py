# monitor/file_monitor.py

import time
import os
import csv
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from datetime import datetime

# مكان حفظ السجل
LOG_FILE = os.path.join("data", "file_log.csv")

# إنشاء الملف في حال عدم وجوده
def init_csv():
    if not os.path.exists("data"):
        os.makedirs("data")

    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "event_type", "file_path"])

# الحدث المخصص الذي يعالج التغييرات
class FileEventHandler(FileSystemEventHandler):
    def on_any_event(self, event):
        if event.is_directory:
            return

        with open(LOG_FILE, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                datetime.now().isoformat(),
                event.event_type,
                event.src_path
            ])
        print(f"[📁] {event.event_type.upper()} → {event.src_path}")

# بدء المراقبة
def start_file_monitoring(path_to_watch="./", interval=1):
    init_csv()
    event_handler = FileEventHandler()
    observer = Observer()
    observer.schedule(event_handler, path=path_to_watch, recursive=True)
    observer.start()
    print(f"[✔] بدأ مراقبة الملفات في: {os.path.abspath(path_to_watch)}")

    try:
        while True:
            time.sleep(interval)
    except KeyboardInterrupt:
        observer.stop()
        print("\n[✖] تم إيقاف مراقبة الملفات.")
    observer.join()

# تشغيل مباشر
if __name__ == "__main__":
    start_file_monitoring(path_to_watch="./")

# monitor/network_monitor.py

import psutil
import csv
import os
import time
import socket
from datetime import datetime

# مكان حفظ السجل
LOG_FILE = os.path.join("data", "network_log.csv")

# إنشاء ملف CSV إذا لم يكن موجودًا
def init_csv():
    if not os.path.exists("data"):
        os.makedirs("data")

    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "timestamp", "pid", "process_name",
                "local_ip", "local_port",
                "remote_ip", "remote_port",
                "status", "protocol"
            ])

# جمع معلومات الاتصالات النشطة
def log_network_connections():
    with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        for conn in psutil.net_connections(kind='inet'):
            try:
                laddr = conn.laddr if conn.laddr else ('', 0)
                raddr = conn.raddr if conn.raddr else ('', 0)
                pid = conn.pid
                proc = psutil.Process(pid) if pid else None
                proc_name = proc.name() if proc else "N/A"
                proto = "TCP" if conn.type == socket.SOCK_STREAM else "UDP"

                writer.writerow([
                    datetime.now().isoformat(),
                    pid,
                    proc_name,
                    laddr.ip if hasattr(laddr, 'ip') else laddr[0],
                    laddr.port if hasattr(laddr, 'port') else laddr[1],
                    raddr.ip if hasattr(raddr, 'ip') else raddr[0],
                    raddr.port if hasattr(raddr, 'port') else raddr[1],
                    conn.status,
                    proto
                ])
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

# بدء المراقبة بشكل دوري
def start_monitoring(interval=10):
    init_csv()
    print(f"[✔] بدأ مراقبة الشبكة كل {interval} ثانية...")
    try:
        while True:
            log_network_connections()
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\n[✖] تم إيقاف مراقبة الشبكة يدويًا.")

# تشغيل مباشر
if __name__ == "__main__":
    start_monitoring(interval=10)

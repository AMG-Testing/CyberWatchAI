# monitor/process_monitor.py
import psutil
import csv
import os
import time
from datetime import datetime

# تحديد مكان حفظ السجل
LOG_FILE = os.path.join("data", "process_log.csv")

# إنشاء ملف CSV مع رؤوس الأعمدة إذا لم يكن موجودًا
def init_csv():
    if not os.path.exists("data"):
        os.makedirs("data")

    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, mode="w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "pid", "name", "username", "cpu_percent", "memory_percent"])

# تسجيل العمليات الحالية
def log_processes():
    with open(LOG_FILE, mode="a", newline="") as f:
        writer = csv.writer(f)
        for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent']):
            try:
                data = proc.info
                writer.writerow([
                    datetime.now().isoformat(),
                    data.get('pid', ''),
                    data.get('name', ''),
                    data.get('username', ''),
                    data.get('cpu_percent', 0.0),
                    data.get('memory_percent', 0.0)
                ])
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

# تشغيل المراقبة بشكل دوري
def start_monitoring(interval=10):
    init_csv()
    print(f"[✔] بدأ مراقبة العمليات كل {interval} ثانية...")
    try:
        while True:
            log_processes()
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\n[✖] تم إيقاف المراقبة يدويًا.")

# لتشغيل السكربت مباشرة
if __name__ == "__main__":
    start_monitoring(interval=10)
